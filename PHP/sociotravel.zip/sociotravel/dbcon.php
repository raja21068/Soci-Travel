<?php

	mysql_select_db('stbbedup_sociotravel',mysql_connect('localhost','stbbedup_socio','google.com'));
	
?>